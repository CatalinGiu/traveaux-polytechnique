//
// Created by catalin on 2/4/19.
//

#ifndef TP1_COUNTING_H
#define TP1_COUNTING_H

int64_t maximum(int64_t arr[], int size);
int64_t* counting(int64_t arr[], int size);
bool print_time;
bool print_array;

#endif //TP1_COUNTING_H
