package ca.polymtl.inf8480.tp1.client;

public class FakeServer {
	int execute(char[] parama) {
		return 0;
	}
}
